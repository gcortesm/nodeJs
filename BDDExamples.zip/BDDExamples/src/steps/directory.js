const { Given, When, Then } = require('cucumber');
const assert = require('assert').strict;
const restHelper = require('../util/resthelper');
let result;
let response;


Given('un contacto {}', (x) => {

  result = JSON.parse(x);
});

When('envio una solicitud POST a {}', async (path) => {
  //console.log(`${process.env.SERVICE_URL}${path}`);
  response = await restHelper.postData(`http://localhost:80${path}`, result);
});

Then('yo obtengo el codigo de respuesta {int}', async (code) => {
  assert.equal(response.status, code);
});